﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using iTextSharp.text;
using iTextSharp.text.pdf;
using System.IO;

namespace MidSemExam
{
    public partial class Bills : Form
    {
        public Bills()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-4TKBODF\SQLEXPRESS;Initial Catalog=Restaurant;Integrated Security=True");

        private void Bills_Load(object sender, EventArgs e)
        {
            fetchdata();
        }
        private void fetchdata()
        {
            String querry = "SELECT * FROM billls";
            SqlDataAdapter adapter = new SqlDataAdapter(querry, con);
            con.Open();
            DataTable dataTable = new DataTable();

            adapter.Fill(dataTable);

            dataGridView.DataSource = dataTable;

        }
        private void generateReport(DataTable data, String filePath)
        {
            Document document = new Document();
            PdfWriter writer = PdfWriter.GetInstance(document, new FileStream(filePath, FileMode.Create));
            document.Open();

            PdfPTable table = new PdfPTable(data.Columns.Count);
            PdfPCell cell;

            foreach (DataColumn column in data.Columns)
            {
                cell = new PdfPCell(new Phrase(column.ColumnName));
                table.AddCell(cell);
            }

            foreach (DataRow row in data.Rows)
            {
                foreach (object item in row.ItemArray)
                {
                    cell = new PdfPCell(new Phrase(item.ToString()));
                    table.AddCell(cell);
                }
            }

            document.Add(table);
            document.Close();
        }

        private void button1_Click(object sender, EventArgs e)

        {
            try
            {
                String querry = "SELECT * FROM billls";
                SqlDataAdapter adapter = new SqlDataAdapter(querry, con);
                if (con.State == ConnectionState.Open)
                    con.Close();
                con.Open();
                DataTable dataTables = new DataTable();

                adapter.Fill(dataTables);

                dataGridView.DataSource = dataTables;
                DataTable dataTable = new DataTable();
                foreach (DataGridViewColumn col in dataGridView.Columns)
                {
                    dataTable.Columns.Add(col.HeaderText);
                }

                foreach (DataGridViewRow row in dataGridView.Rows)
                {
                    if (!row.IsNewRow)
                    {
                        DataRow dataRow = dataTable.NewRow();
                        foreach (DataGridViewCell cell in row.Cells)
                        {
                            dataRow[cell.ColumnIndex] = cell.Value;
                        }
                        dataTable.Rows.Add(dataRow);
                    }
                }

                string filePath = @"C:\\Users\\HP\\Desktop\\report.pdf";

        
                generateReport(dataTable, filePath);

                MessageBox.Show("Report saved to: " + filePath);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }
        }
    }
    }
