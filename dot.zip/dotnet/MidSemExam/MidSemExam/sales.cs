﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace MidSemExam
{
    public partial class sales : Form
    {
        public sales()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-4TKBODF\SQLEXPRESS;Initial Catalog=Restaurant;Integrated Security=True");

        private void sales_Load(object sender, EventArgs e)
        {
            fetchdata();
        }
        private void fetchdata()
        {
            String querry = "SELECT * FROM billls";
            SqlDataAdapter adapter = new SqlDataAdapter(querry, con);
            con.Open();
            DataTable dataTable = new DataTable();

            adapter.Fill(dataTable);

            dataGridView1.DataSource = dataTable;

        }
    }
}
