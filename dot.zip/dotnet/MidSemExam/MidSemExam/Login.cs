﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using BCrypt.Net;

namespace MidSemExam
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-4TKBODF\SQLEXPRESS;Initial Catalog=Restaurant;Integrated Security=True");
        String userloggedin = "";
        private void Login_Load(object sender, EventArgs e)
        {

        }
        public void SetLoggedInUsername(string username)
        {
            userloggedin = username;
        }
        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            new SIgnupform().Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            String email = emailBox.Text;
            String pass = passBox.Text;


            String querry = "SELECT * from usereg";
            SqlCommand cmd = new SqlCommand(querry, con);
            con.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                String password = reader["password"].ToString();
                String emails = reader["email"].ToString();
                userloggedin = reader["names"].ToString();
                SetLoggedInUsername(userloggedin);
                bool isPasswordValid = BCrypt.Net.BCrypt.Verify(pass, password);

                if (isPasswordValid && email.Equals(emails))
                {
                    {
                        MessageBox.Show("Login succesful");
                        this.Hide();
                        CashierHomePage home = new CashierHomePage();
                        home.setUserLoggedin(userloggedin);
                        home.Show();

                       

                    }
                    
                }

            }

            con.Close();

        }
    }
}
