﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace MidSemExam
{
    public partial class Menu : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-4TKBODF\SQLEXPRESS;Initial Catalog=Restaurant;Integrated Security=True");
        public Menu()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            String name = textBox1.Text;
            int price =int.Parse(textBox2 .Text);
            String cat = comboBox.SelectedItem.ToString();

            string querry = "INSERT INTO menu(name,category,price) VALUES(@Name,@Cate,@Price)";
            SqlCommand cmd = new SqlCommand(querry, con);
            cmd.Parameters.Add("@Name", SqlDbType.VarChar).Value = name;
            cmd.Parameters.Add("@Cate", SqlDbType.VarChar).Value = cat;
            cmd.Parameters.Add("@Price", SqlDbType.Int).Value = price;
            con.Open();
            int rwos = cmd.ExecuteNonQuery();

            if (rwos > 0)
            {
                MessageBox.Show("Item Saved");
                this.Hide();
                new CashierHomePage().Show();

            }
            else
            {
                MessageBox.Show("Item Not saved");

            }
            con.Close();

        }
    }
}
