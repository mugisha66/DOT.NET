﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace MidSemExam
{
    public partial class CashierHomePage : Form
    {
        public CashierHomePage()
        {
            InitializeComponent();
        }
        DateTime dates = DateTime.Today;
        String user = "";
        int total = 0;
        int totalTax = 0;
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-4TKBODF\SQLEXPRESS;Initial Catalog=Restaurant;Integrated Security=True");
        private void CashierHomePage_Load(object sender, EventArgs e)
        {
            fetchdata();

        }
        public void setUserLoggedin(String username)
        {
            label1.Text = "Welcome, " + username;
            user = username;
        }
        private void fetchdata()
        {
            String querry = "SELECT * FROM menu";
            SqlDataAdapter adapter = new SqlDataAdapter(querry, con);
            con.Open();
            DataTable dataTable = new DataTable();

            adapter.Fill(dataTable);

            // Bind the DataTable to the DataGridView
            dataGridView.DataSource = dataTable;

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int id = int.Parse(idBox.Text);
            String querry = "Select * FROM menu where id=@Id";
            SqlCommand cmd = new SqlCommand(querry, con);
            cmd.Parameters.Add("@Id", SqlDbType.Int).Value = id;
            SqlDataReader reader = cmd.ExecuteReader();
            if (reader.Read())
            {
                nameBox.Text = reader["name"].ToString();
                priceBox.Text = reader["price"].ToString();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            String names = nameBox.Text;
            int price = int.Parse(priceBox.Text);
            int quantity = int.Parse(quantityBox.Text);
            String Payment = comboBox1.SelectedItem.ToString();
            total = price * quantity;
            string querry = "insert into billls(name,price,quantity,total,dates,payment) values(@Names,@price,@quantity,@total,@dates,@Pay)";
            SqlCommand cmd = new SqlCommand(querry, con);
            if (con.State == ConnectionState.Open)
                con.Close();
            con.Open();
            cmd.Parameters.Add("@Names", SqlDbType.VarChar).Value = names;
            cmd.Parameters.Add("@price", SqlDbType.Int).Value = price;
            cmd.Parameters.Add("@quantity", SqlDbType.Int).Value = quantity;
            cmd.Parameters.Add("@total", SqlDbType.Int).Value = total;
            cmd.Parameters.Add("@dates", SqlDbType.DateTime).Value = dates;
            cmd.Parameters.Add("@Pay", SqlDbType.VarChar).Value = Payment;
            int rwos = cmd.ExecuteNonQuery();
            if (rwos > 0)
            {
                MessageBox.Show("Order saved");

            }
            else
            {
                MessageBox.Show("Order not saved");



            }

            con.Close();




        }

        private void CreateMenu_Click(object sender, EventArgs e)
        {
            new Menu().Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            new Bills().Show();
            this.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            new sales().Show();
            this.Hide();
        }
    }
    
}
