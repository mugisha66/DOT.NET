﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using BCrypt.Net;
namespace MidSemExam
{
    public partial class SIgnupform : Form
    {
        public SIgnupform()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-4TKBODF\SQLEXPRESS;Initial Catalog=Restaurant;Integrated Security=True");

        private void SIgnupform_Load(object sender, EventArgs e)
        {

        }
        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            new Login().Show();
            this.Hide();

        }

        private void signupButton_Click(object sender, EventArgs e)
        {
            String names = nameBox.Text;
            String email = emailBox.Text;
            String pass = passBox.Text;
            String hash= BCrypt.Net.BCrypt.HashPassword(pass);
            if (email.Contains("@gmail.com"))
            {

                string querry = "INSERT INTO usereg(names,email,password) VALUES(@Names,@Email,@Pass)";
                SqlCommand cmd = new SqlCommand(querry, con);
                cmd.Parameters.Add("@Names", SqlDbType.VarChar).Value = names;
                cmd.Parameters.Add("@Email", SqlDbType.VarChar).Value = email;
                cmd.Parameters.Add("@Pass", SqlDbType.VarChar).Value = hash;
                con.Open();
                int rwos = cmd.ExecuteNonQuery();

                if (rwos > 0)
                {
                    MessageBox.Show("User Registered");
                    this.Hide();
                    new Login().Show();

                }
                else
                {
                    MessageBox.Show("User Not Registered");

                }
                con.Close();
            }
            else
            {
                MessageBox.Show("enter valid email");
            }

        }
    }
}
