﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace StudentRequestPortal
{
    public partial class Signup : Form
    {
        public Signup()
        {
            InitializeComponent();
        }
        public void populateDepartmentBox()
        {
            // Fetch all Departments
            String qry = "SELECT * from Department";
            SqlDataAdapter sda = new SqlDataAdapter(qry, conn);
            // Add them in a dataset
            DataSet ds = new DataSet();
            sda.Fill(ds, "Department");
            // Display them in a combo
            departmentBox.DataSource = ds.Tables["Department"];
            departmentBox.DisplayMember = "deptName";
            departmentBox.ValueMember = "deptId";
        }

        public void viewAllData()
        {
            // Fetch all Departments
            String qry = "SELECT * from Student";
            SqlDataAdapter sda = new SqlDataAdapter(qry, conn);
            // Add them in a dataset
            DataSet ds = new DataSet();
            sda.Fill(ds, "Student");
            // Display them in a combo
            studentDataGridView.DataSource = ds.Tables["Student"];
        }


        SqlConnection conn = new SqlConnection(@"Data Source=DESKTOP-QV37GS8;Initial Catalog=StudentPortalDB;Integrated Security=True");
        private void Signup_Load(object sender, EventArgs e)
        {
        populateDepartmentBox();
        viewAllData();
        }

    private void submitBtn_Click(object sender, EventArgs e)
        {
            // Create the saving pipe-Querry in SQLDATA
            String fullName = firstNameBox.Text + " " + lastNameBox.Text;
            //String fac = facultyBox.Text;
            String dept = departmentBox.SelectedValue.ToString();
            String program = "Day";
            String email = emailBox.Text;
            String pass = passwordBox.Text;
            String query = "INSERT INTO Student Values('" + fullName + "','" + dept + "','" + program + "','" + email + "','" + pass + "')";
            SqlDataAdapter sda = new SqlDataAdapter(query,conn);
            conn.Open();
            // Save to the database
            sda.SelectCommand.ExecuteNonQuery();
            MessageBox.Show("Student saved with Success");
            viewAllData();
        }
        
        private void button1_Click(object sender, EventArgs e)
        {
            Department dptform = new Department();
            dptform.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // Create the saving pipe-Querry in SQLDATA
            String fullName = firstNameBox.Text + " " + lastNameBox.Text;
            //String fac = facultyBox.Text;
            String dept = departmentBox.SelectedValue.ToString();
            String program = "Day";
            String email = emailBox.Text;
            //String pass = passwordBox.Text;
            String query = "UPDATE STUDENT SET fullnames='" + fullName + "', department='" + dept + "', program='" + program + "', email='" + email + "' WHERE id='"+ idBox.Text +"'";
            SqlDataAdapter sda = new SqlDataAdapter(query, conn);
            conn.Open();
            // Save to the database
            sda.SelectCommand.ExecuteNonQuery();
            MessageBox.Show("Student updated with Success");
            //viewAllData();
        }

        private void studentDataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int selectedRowIndex = studentDataGridView.SelectedCells[0].RowIndex;
            idBox.Text = studentDataGridView.Rows[selectedRowIndex].Cells["id"].Value.ToString();
            firstNameBox.Text = studentDataGridView.Rows[selectedRowIndex].Cells["fullnames"].Value.ToString().Split(" ");
            lastNameBox.Text = studentDataGridView.Rows[selectedRowIndex].Cells["fullnames"].Value.ToString().Split(" ");
            departmentBox.Text = studentDataGridView.Rows[selectedRowIndex].Cells["department"].Value.ToString();
            emailBox.Text = studentDataGridView.Rows[selectedRowIndex].Cells["email"].Value.ToString();
        }
    }
}
