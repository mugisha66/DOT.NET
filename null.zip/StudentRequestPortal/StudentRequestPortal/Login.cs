﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudentRequestPortal
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void linkLabelTxt_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Signup signupForm = new Signup();
            this.Hide();
            signupForm.Show();
        }

        private void loginBtn_Click(object sender, EventArgs e)
        {
            if(idEmailBox.Text =="admin@gmail.com"
                && passwordBox.Text == "password")
            {
                HomePage pg = new HomePage();
                pg.Show();
            }
            else
            {
                MessageBox.Show("Incorrect username and or Password");
            }
        }

        private void passwordBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void idEmailBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
