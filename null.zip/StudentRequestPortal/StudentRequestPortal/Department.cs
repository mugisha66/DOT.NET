﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace StudentRequestPortal
{
    public partial class Department : Form
    {
        public Department()
        {
            InitializeComponent();
        }

        private void emailBox_TextChanged(object sender, EventArgs e)
        {

        }
        SqlConnection conn = new SqlConnection(@"Data Source=DESKTOP-QV37GS8;Initial Catalog=StudentPortalDB;Integrated Security=True");

        private void submitBtn_Click(object sender, EventArgs e)
        {
            // Create the saving pipe-Querry in SQLDATA
            String faculty = facultyBox.Text;
            String dept = deptNameField.Text;
            
            String query = "INSERT INTO Department Values('" + faculty + "','" + dept + "')";
            SqlDataAdapter sda = new SqlDataAdapter(query, conn);
            if(conn.State == ConnectionState.Closed)
                conn.Open();
            // Save to the database
            sda.SelectCommand.ExecuteNonQuery();
            conn.Close();
            MessageBox.Show("Department saved with Success");
        }
    }
}
